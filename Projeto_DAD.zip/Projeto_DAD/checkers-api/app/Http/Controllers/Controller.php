<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

abstract class Controller
{
    public function play(Request $request, $id) 
    {
        $validated = $request->validate([
            'from_row' => 'required|integer',
            'from_col' => 'required|integer',
            'to_row' => 'required|integer',
            'to_col' => 'required|integer',
        ]);

        return response()->json([
            'message' => 'Jogada recebida com sucesso!',
            'game_id' => $id,
            'move' => $validated
        ]);
    }   
    public function index(Request $request)
    {
        // Mais tarde: $games = Game::all(); ou Game::where('status', 'waiting')->get();
        return response()->json([
            'data' => [
                ['id' => 1, 'status' => 'waiting', 'player1' => 'test@example.com'],
                ['id' => 2, 'status' => 'waiting', 'player1' => 'second@example.com']
            ]
        ]);
    }

    public function store(Request $request)
    {
        // Mais tarde: Lógica para inserir na BD
        return response()->json([
            'message' => 'Jogo criado com sucesso!',
            'game_id' => random_int(3, 99) // ID gerado para ele testar entrar na sala
        ], 201);
    }
}
